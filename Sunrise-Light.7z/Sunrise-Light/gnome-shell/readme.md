# Credits
Sunrise Gnome shell themes base on [Adwaita](https://gitlab.gnome.org/GNOME/gtk/-/tree/gtk-3-24/gtk/theme/Adwaita) </br>
License : GPLv3 (https://choosealicense.com/licenses/gpl-3.0/)</br>

# Installation
Extract archive file On directory <i> /usr/share/themes (as root)</i> Or <i> /.themes</i> Or <i> /.local/share/themes</i></br>

# Use the themes
Gnome Desktop: Use Tweak Tool to change the themes, <i>Gnome Tweak > Appeareance > Themes > Shell</i></br>
